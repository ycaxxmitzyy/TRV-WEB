/**
 * Nature Gateway— shared UI helpers
 * Plain JavaScript: inline SVG icons, markup fragments, toasts and dialogs.
 */

import { getBookings, getDepartures, formatDate, peso } from "./store.js";

const ICON_PATHS = {
  compass: '<circle cx="12" cy="12" r="10"/><polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76"/>',
  "arrow-right": '<path d="M5 12h14M12 5l7 7-7 7"/>',
  "arrow-up-right": '<path d="M7 17 17 7M7 7h10v10"/>',
  "arrow-left": '<path d="M19 12H5M12 19l-7-7 7-7"/>',
  search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
  star: '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
  calendar: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
  users:
    '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
  clock: '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
  shield:
    '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/>',
  leaf: '<path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z"/><path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12"/>',
  "map-pin":
    '<path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0"/><circle cx="12" cy="10" r="3"/>',
  mail: '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-8.97 5.7a2 2 0 0 1-2.06 0L2 7"/>',
  phone:
    '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/>',
  check: '<path d="M20 6 9 17l-5-5"/>',
  "check-circle": '<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>',
  "x-circle": '<circle cx="12" cy="12" r="10"/><path d="m15 9-6 6M9 9l6 6"/>',
  trash:
    '<path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>',
  pencil:
    '<path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/>',
  eye:
  '<path d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"/><circle cx="12" cy="12" r="3"/>',
  download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  minus: '<path d="M5 12h14"/>',
  x: '<path d="M18 6 6 18M6 6l12 12"/>',
  menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
  "alert-circle": '<circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/>',
  "help-circle": '<circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3M12 17h.01"/>',
  "credit-card": '<rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20"/>',
  printer:
    '<polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/>',
  "file-text":
    '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v5h5M16 13H8M16 17H8M10 9H8"/>',
  refresh: '<path d="M3 12a9 9 0 0 1 15-6.7L21 8M21 3v5h-5M21 12a9 9 0 0 1-15 6.7L3 16M3 21v-5h5"/>',
  database:
    '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v14a9 3 0 0 0 18 0V5M3 12a9 3 0 0 0 18 0"/>',
  clipboard:
    '<rect x="8" y="2" width="8" height="4" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="M12 11h4M12 16h4M8 11h.01M8 16h.01"/>',
  "list-checks": '<path d="m3 17 2 2 4-4M3 7l2 2 4-4M13 6h8M13 12h8M13 18h8"/>',
  "more-horizontal": '<circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/>',
  sparkle: '<path d="M12 3v18M3 12h18"/>',
};

export function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (char) => {
    const map = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };
    return map[char];
  });
}

export function icon(name, extraClass = "") {
  const path = ICON_PATHS[name] || ICON_PATHS.compass;
  return `<svg class="icon ${extraClass}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${path}</svg>`;
}

export function stars(count = 5) {
  return `<span class="stars" aria-hidden="true">${Array.from({ length: count })
    .map(() => icon("star", "icon--fill"))
    .join("")}</span>`;
}

export function statusBadge(status) {
  return `<span class="status status--${status.toLowerCase()}">${escapeHtml(status)}</span>`;
}

export function packageCard(pkg) {
  const departures = getDepartures(pkg, getBookings()).filter((departure) => !departure.isPast);
  const next = departures.find((departure) => departure.available > 0) || departures[0] || null;
  const lowSeats = next && next.available <= 3;

  return `
    <article class="pkg-card">
      <a class="pkg-card__media" href="#/book?package=${encodeURIComponent(pkg.slug)}" aria-label="Book ${escapeHtml(pkg.name)}">
        <img src="${escapeHtml(pkg.image)}" alt="${escapeHtml(pkg.imageAlt)}" loading="lazy">
        <span class="pkg-card__chip">${escapeHtml(pkg.category)}</span>
        <span class="pkg-card__rating">${icon("star", "icon--fill")} ${pkg.rating.toFixed(1)}</span>
        <div class="pkg-card__caption">
          <p>${escapeHtml(pkg.region)} · ${pkg.durationDays}D${pkg.durationDays - 1}N</p>
          <p>${escapeHtml(pkg.destination)}</p>
        </div>
      </a>
      <div class="pkg-card__body">
        <div>
          <h3><a href="#/book?package=${encodeURIComponent(pkg.slug)}">${escapeHtml(pkg.name)}</a></h3>
          <p class="pkg-card__tagline">${escapeHtml(pkg.tagline)}</p>
        </div>
        <div class="pkg-meta">
          <span>${icon("clock")} ${pkg.durationDays} days</span>
          ${next ? `<span>${icon("calendar")} ${formatDate(next.date)}</span>` : ""}
          <span class="${lowSeats ? "is-low" : ""}">${icon("users")} ${
            next && next.available > 0 ? `${next.available} seats left` : "Waitlist only"
          }</span>
        </div>
        <div class="pkg-card__foot">
          <div>
            <span class="price-label">From</span>
            <p class="price">${peso(pkg.pricePerPerson)} <small>/ person</small></p>
          </div>
          <a class="btn btn--sm" href="#/book?package=${encodeURIComponent(pkg.slug)}">
            View trip ${icon("arrow-right")}
          </a>
        </div>
      </div>
    </article>
  `;
}

export function emptyState({ iconName = "search", title, message, action = "" }) {
  return `
    <div class="empty-state">
      <span class="round-icon">${icon(iconName)}</span>
      <h3>${escapeHtml(title)}</h3>
      <p>${escapeHtml(message)}</p>
      ${action}
    </div>
  `;
}
export function toast(message, type = "success") {
  const region = document.getElementById("toast-region");
  if (!region) return;
  const el = document.createElement("div");
  el.className = `toast toast--${type}`;
  el.setAttribute("role", type === "error" ? "alert" : "status");
  el.innerHTML = `${icon(type === "error" ? "alert-circle" : "check-circle")}<span>${escapeHtml(message)}</span>`;
  region.append(el);
  window.setTimeout(() => el.remove(), 4600);
}

/* ------------------------------------------------------------------ */
/* Confirmation dialog                                                 */
/* ------------------------------------------------------------------ */

export function openConfirm({ title, description, confirmLabel = "Confirm", tone = "danger", onConfirm }) {
  const dialog = document.getElementById("confirm-dialog");
  if (!dialog) return;

  const titleEl = document.getElementById("confirm-title");
  const textEl = document.getElementById("confirm-text");
  const cancelBtn = document.getElementById("confirm-cancel");
  const acceptBtn = document.getElementById("confirm-accept");

  titleEl.textContent = title;
  textEl.textContent = description;
  acceptBtn.textContent = confirmLabel;
  acceptBtn.className = tone === "danger" ? "btn btn--danger" : "btn";

  cancelBtn.onclick = () => dialog.close();
  acceptBtn.onclick = () => {
    dialog.close();
    onConfirm();
  };

  dialog.showModal();
}

export function openDialog(id) {
  const dialog = document.getElementById(id);
  if (dialog && !dialog.open) dialog.showModal();
}

export function closeDialog(id) {
  const dialog = document.getElementById(id);
  if (dialog && dialog.open) dialog.close();
}
