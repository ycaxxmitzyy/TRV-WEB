import { HERO_IMAGE, PACKAGES, CATEGORIES, REGIONS } from "./data.js";
import { getBookings, getDepartures, formatDate, peso } from "./store.js";
import { escapeHtml, icon, packageCard, stars } from "./ui.js";

const featuredPackages = () => PACKAGES.filter((pkg) => pkg.featured).slice(0, 3);

function renderStats() {
  return `
    <dl class="stats-band" aria-label="Nature Gateway at a glance">
      <div><dt>Curated trips</dt><dd>${PACKAGES.length}</dd></div>
      <div><dt>Regions covered</dt><dd>${REGIONS.length}</dd></div>
      <div><dt>Guest rating</dt><dd>4.8/5</dd></div>
      <div><dt>Local experiences</dt><dd>100%</dd></div>
    </dl>`;
}

function renderNextTrip() {
  const pkg = PACKAGES.find((item) => item.featured) || PACKAGES[0];
  const departures = getDepartures(pkg, getBookings()) || [];
  const next = departures[0];
  const departureDate = next?.date ? formatDate(next.date) : "Dates available";
  const seats = Number.isFinite(next?.seats) ? `${next.seats} seats left` : "Small group";

  return `
    <aside class="hero__aside">
      <article class="next-card">
        <div class="next-card__head">
          <span class="next-card__label">A traveller favourite</span>
          <span class="next-card__seats">${escapeHtml(seats)}</span>
        </div>
        <h3>${escapeHtml(pkg.name)}</h3>
        <p class="hint">${escapeHtml(pkg.destination)}</p>
        <dl class="next-card__grid">
          <div><dt>Next departure</dt><dd>${escapeHtml(departureDate)}</dd></div>
          <div><dt>Duration</dt><dd>${pkg.durationDays} days</dd></div>
          <div><dt>From</dt><dd>${peso(pkg.pricePerPerson)}</dd></div>
          <div><dt>Guest rating</dt><dd>${pkg.rating.toFixed(1)} / 5</dd></div>
        </dl>
        <a class="btn btn--block" href="#packages">Explore this trip →</a>
      </article>
    </aside>`;
}

function renderSearch() {
  return `
    <div class="search-wrap container">
      <form class="search-form surface" id="home-search" role="search">
        <div class="field">
          <label for="home-query">Where would you like to go?</label>
          <div class="input-icon">
            ${icon("search", "icon")}
            <input class="input" id="home-query" name="query" type="search"
              placeholder="Try Palawan, beaches, mountains..." autocomplete="off">
          </div>
        </div>
        <div class="field">
          <label for="home-category">Travel style</label>
          <select class="select" id="home-category" name="category">
            <option value="">All experiences</option>
            ${CATEGORIES.map((category) => `<option value="${escapeHtml(category)}">${escapeHtml(category)}</option>`).join("")}
          </select>
        </div>
        <button class="btn btn--sun btn--lg search-form__submit" type="submit">
          ${icon("search")} Find a trip
        </button>
      </form>
    </div>`;
}

function renderHowItWorks() {
  const steps = [
    ["01", "Find your kind of trip", "Browse thoughtfully planned getaways across Luzon, Visayas and Mindanao."],
    ["02", "Make it yours", "Choose your departure, group size and optional add-ons in the booking form."],
    ["03", "Get ready to go", "Keep your booking reference and trip details handy as your travel date approaches."]
  ];
  return `
    <section class="section band" id="how-it-works">
      <div class="container">
        <div class="section-heading section-heading--center">
          <div><span class="hero__badge" style="background:var(--primary);color:white;border:0">A simpler way to explore</span>
            <h2>Three steps to your next story</h2>
            <p>From first browse to departure day, we keep planning clear and uncomplicated.</p>
          </div>
        </div>
        <div class="step-list">
          ${steps.map(([num, title, copy]) => `
            <article class="step">
              <span class="step__num">${num}</span>
              <h3>${title}</h3>
              <p>${copy}</p>
            </article>`).join("")}
        </div>
      </div>
    </section>`;
}

function renderValues() {
  const values = [
    ["leaf", "Travel thoughtfully", "We work with local guides and community-run stays so more of each journey supports its destination."],
    ["map-pin", "Know what to expect", "Clear inclusions, trip durations and departure details help you plan with confidence."],
    ["users", "Small-group moments", "Enjoy a more personal pace, with room to connect with the people and places along the way."]
  ];
  return `
    <section class="section" id="about">
      <div class="container">
        <div class="section-heading">
          <div><p class="eyebrow">Why Nature Gateway</p><h2>More than a place on the map</h2>
            <p>We believe the best journeys make space for local stories, meaningful encounters and the freedom to slow down.</p>
          </div>
        </div>
        <div class="value-grid">
          ${values.map(([symbol, title, copy]) => `
            <article class="value-card">
              <span class="round-icon">${icon(symbol)}</span>
              <h3>${title}</h3><p>${copy}</p>
            </article>`).join("")}
        </div>
      </div>
    </section>`;
}

export function renderHome() {
  const featured = featuredPackages();
  const hero = `
    <section class="hero" id="home">
      <img class="hero__img" src="${escapeHtml(HERO_IMAGE)}" alt="Tropical Philippine coastline" fetchpriority="high">
      <div class="hero__overlay" aria-hidden="true"></div>
      <div class="container hero__grid">
        <div class="hero__copy">
          <span class="hero__badge">${icon("compass")} Find your own way around the islands</span>
          <h1>Every journey has a <span>story worth telling.</span></h1>
          <p class="hero__lead">Discover the Philippines at your own pace with thoughtfully planned local experiences, welcoming guides and unforgettable places.</p>
          <div class="hero__actions">
            <a class="btn btn--sun btn--xl" href="#packages">Explore destinations →</a>
            <a class="btn btn--hero btn--xl" href="#how-it-works">How it works</a>
          </div>
          <div class="hero__trust">
            <span>${stars(5)} <strong>4.8/5</strong> traveller rating</span>
            <span>${icon("shield")} Clear trip details</span>
            <span>${icon("leaf")} Local-first experiences</span>
          </div>
        </div>
        ${renderNextTrip()}
      </div>
    </section>`;

  const packageSection = `
    <section class="section" id="packages">
      <div class="container">
        <div class="section-heading">
          <div><p class="eyebrow">Made for curious travellers</p>
            <h2>Find a trip that feels like you</h2>
            <p>Island days, mountain mornings and cultural encounters — start with one of our handpicked Philippine journeys.</p>
          </div>
          <a class="text-link" href="#packages">Browse all ${PACKAGES.length} trips</a>
        </div>
        <div class="results-bar" id="home-results-bar">
          <span id="home-results-count">Showing ${featured.length} featured journeys</span>
          <button class="btn btn--ghost btn--sm" id="clear-home-search" type="button" hidden>Clear search</button>
        </div>
        <div class="card-grid" id="home-package-grid">
          ${featured.map(packageCard).join("")}
        </div>
        <p class="note-row">Want to compare every destination? <a href="#all-trips">See all available journeys</a></p>
        <div class="card-grid" id="all-trips" hidden>${PACKAGES.map(packageCard).join("")}</div>
      </div>
    </section>`;

  return `
    ${hero}
    ${renderSearch()}
    <div class="container">${renderStats()}</div>
    ${packageSection}
    ${renderHowItWorks()}
    ${renderValues()}
    <section class="section">
      <div class="container">
        <figure class="quote">
          <span class="quote__mark" aria-hidden="true">“</span>
          <div>
            <blockquote>The best part of travelling is coming home with a little more of the world in you.</blockquote>
            <figcaption><strong>Nature Gateway</strong><span>Go gently. See deeply. Travel kindly.</span></figcaption>
          </div>
        </figure>
      </div>
    </section>
    <section class="section section--tight" id="contact">
      <div class="container">
        <div class="cta-band">
          <div><p class="hero__badge">Your next chapter starts here</p>
            <h2>Ready to see more of the Philippines?</h2>
            <p>Explore the trips, find a date that works and start planning your next getaway.</p>
          </div>
          <div class="cta-band__actions"><a class="btn btn--sun btn--xl" href="#packages">Find your trip →</a></div>
        </div>
      </div>
    </section>`;
}

export function bindHomeEvents() {
  const form = document.querySelector("#home-search");
  const queryInput = document.querySelector("#home-query");
  const categoryInput = document.querySelector("#home-category");
  const grid = document.querySelector("#home-package-grid");
  const count = document.querySelector("#home-results-count");
  const clearButton = document.querySelector("#clear-home-search");
  const allTrips = document.querySelector("#all-trips");

  if (!form || !grid) return;

  const showPackages = (packages, label) => {
    grid.innerHTML = packages.length
      ? packages.map(packageCard).join("")
      : `<div class="empty-state" style="grid-column:1/-1">
          ${icon("search")}<h3>No trips found</h3>
          <p>Try another destination or travel style.</p>
        </div>`;
    count.textContent = label;
    clearButton.hidden = !queryInput.value && !categoryInput.value;
  };

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const query = queryInput.value.trim().toLowerCase();
    const category = categoryInput.value;
    const matches = PACKAGES.filter((pkg) => {
      const text = [pkg.name, pkg.destination, pkg.region, pkg.category, pkg.tagline].join(" ").toLowerCase();
      return (!query || text.includes(query)) && (!category || pkg.category === category);
    });
    showPackages(matches, `${matches.length} ${matches.length === 1 ? "journey" : "journeys"} found`);
    document.querySelector("#packages")?.scrollIntoView({ behavior: "smooth" });
  });

  clearButton.addEventListener("click", () => {
    form.reset();
    showPackages(featuredPackages(), `Showing ${featuredPackages().length} featured journeys`);
  });

  document.querySelector('a[href="#all-trips"]')?.addEventListener("click", (event) => {
    event.preventDefault();
    allTrips.hidden = false;
    allTrips.scrollIntoView({ behavior: "smooth", block: "start" });
  });
}